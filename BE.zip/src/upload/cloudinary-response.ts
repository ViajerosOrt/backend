export interface CloudinaryResponse {
  secure_url: string;
  public_id: string;
}